# -*- coding: utf-8 -*-
# @Date    : 2020-07-01
# @Author  : Shawn Shan (shansixiong@cs.uchicago.edu)
# @Link    : https://www.shawnshan.com/


from .protection import main

if __name__ == '__main__':
    main()
